## **注意**

- nikke有三类json：
  - catalog_131.10.2K、catalog_c70e7a9.json、physics-catalog_c70e7a9.db.dec.json

- 格式可以概括如下：
  - **catalog_数字.数字.英文**（这类通常会带小数点）
  - **catloag_String**（这类通常被_分成两段）
  - **以physics-catalog开头**

- 在使用这个一键repack脚本时，**貌似只需要catalog_数字.数字.英文这类json**（作者原给的文件夹就是如此），**因此仅需把该文件移动到上级目录即可**。

------

## json数据获取地址

discord服务器名：**Destiny Child International**

邀请链接：https://discord.gg/destiny-child-international-241679077658984448

进入到**/Nikke/nikke-no-mobile-modding-chat**中可以找到上述三类json文件，**注意只用新不用旧**。（可以结合关键词”catalog“进行搜索，加快查找速度。）